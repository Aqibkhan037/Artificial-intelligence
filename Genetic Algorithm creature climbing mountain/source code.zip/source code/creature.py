import genome
from xml.dom.minidom import getDOMImplementation
from enum import Enum
import numpy as np
import pybullet as p

class MotorType(Enum):
    PULSE = 1
    SINE = 2

class Motor:
    def __init__(self, control_waveform, control_amp, control_freq, index):
        if control_waveform <= 0.5:
            self.motor_type = MotorType.PULSE
        else:
            self.motor_type = MotorType.SINE
        self.amp = control_amp
        self.freq = control_freq
        self.phase = 0
        self.index = index
    
    def get_output(self):
        self.phase = (self.phase + self.freq) % (np.pi * 2)
        if self.motor_type == MotorType.PULSE:
            output = 1 if self.phase < np.pi else -1
        elif self.motor_type == MotorType.SINE:
            output = np.sin(self.phase)
        return output * self.amp

class Creature:
    def __init__(self, gene_count):
        self.spec = genome.Genome.get_gene_spec()
        self.dna = genome.Genome.get_random_genome(len(self.spec), gene_count)
        self.flat_links = None
        self.exp_links = None
        self.motors = None
        self.start_position = None
        self.last_position = None

    def get_flat_links(self):
        if self.flat_links is None:
            gdicts = genome.Genome.get_genome_dicts(self.dna, self.spec)
            self.flat_links = genome.Genome.genome_to_links(gdicts)
        return self.flat_links
    
    def get_expanded_links(self):
        self.get_flat_links()
        if self.exp_links is not None:
            return self.exp_links
        
        exp_links = [self.flat_links[0]]
        genome.Genome.expandLinks(self.flat_links[0], self.flat_links[0].name, self.flat_links, exp_links)
        self.exp_links = exp_links
        return self.exp_links

    def to_xml(self):
        self.get_expanded_links()
        domimpl = getDOMImplementation()
        adom = domimpl.createDocument(None, "start", None)
        robot_tag = adom.createElement("robot")
        
        for link in self.exp_links:
            robot_tag.appendChild(link.to_link_element(adom))
        
        first = True
        for link in self.exp_links:
            if first:  # Skip the root node!
                first = False
                continue
            robot_tag.appendChild(link.to_joint_element(adom))
        
        robot_tag.setAttribute("name", "attractive_creature")  # Choose a name!
        return '<?xml version="1.0"?>' + robot_tag.toprettyxml()

    def get_motors(self):
        self.get_expanded_links()
        if self.motors is None:
            motors = [Motor(link.control_waveform, link.control_amp, link.control_freq, index) 
                      for index, link in enumerate(self.exp_links[1:], start=0)]  # start=0 to match joint index
            self.motors = motors
        return self.motors 
    
    def update_position(self, pos):
        if self.start_position is None:
            self.start_position = pos
        else:
            self.last_position = pos

    def get_distance_travelled(self):
        if self.start_position is None or self.last_position is None:
            return 0
        p1 = np.asarray(self.start_position)
        p2 = np.asarray(self.last_position)
        return np.linalg.norm(p1 - p2)

    def update_dna(self, dna):
        self.dna = dna
        self.flat_links = None
        self.exp_links = None
        self.motors = None
        self.start_position = None
        self.last_position = None

    def get_action(self):
        actions = [motor.get_output() for motor in self.get_motors()]
        # Limit the actions to prevent jumping and favor crawling
        actions = np.clip(actions, -0.5, 0.5)
        return actions

def run_simulation(creature, simulation_time=1000):
    p.resetSimulation()
    p.setGravity(0, 0, -10)
    arena_size = 20
    make_arena(arena_size=arena_size)
    
    # Load the mountain
    mountain_position = (0, 0, -1)
    mountain_orientation = p.getQuaternionFromEuler((0, 0, 0))
    p.setAdditionalSearchPath('shapes/')
    mountain_id = p.loadURDF("gaussian_pyramid.urdf", mountain_position, mountain_orientation, useFixedBase=1)

    # Load the creature from its URDF
    creature_xml = creature.to_xml()
    with open('test.urdf', 'w') as f:
        f.write(creature_xml)

    # Set initial position of the creature at the base of the mountain
    initial_position = (0, -arena_size/2 + 2, 0.5)
    creature_id = p.loadURDF('test.urdf', initial_position)

    # Get the number of joints in the creature
    num_joints = p.getNumJoints(creature_id)

    # Run the simulation
    for _ in range(simulation_time):
        # Get the creature's action (joint torques)
        action = creature.get_action()

        # Ensure the action array has the same length as the number of joints
        if len(action) > num_joints:
            action = action[:num_joints]
        elif len(action) < num_joints:
            action.extend([0] * (num_joints - len(action)))

        # Apply the action to the creature's joints
        for i in range(num_joints):
            p.setJointMotorControl2(creature_id, i, p.TORQUE_CONTROL, force=action[i])

        p.stepSimulation()
        
        # Check if the creature has reached the top of the mountain
        pos, _ = p.getBasePositionAndOrientation(creature_id)
        if np.allclose(pos, [0, 0, 5], atol=0.1):
            print("Creature has reached the top of the mountain!")
            break
        
        # Check if the creature is out of bounds and reset it if necessary
        if abs(pos[0]) > arena_size/2 or abs(pos[1]) > arena_size/2:
            p.resetBasePositionAndOrientation(creature_id, initial_position, [0, 0, 0, 1])
        
        time.sleep(1/240)

    return fitness_function(creature_id)

# Add the rest of your code here, including the main function and the fitness function