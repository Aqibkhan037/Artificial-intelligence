import pybullet as p
import pybullet_data
import time
import numpy as np
from geneticAlgorithm import GeneticAlgorithm
from creature import Creature

# Connect to PyBullet
p.connect(p.GUI)
p.setAdditionalSearchPath(pybullet_data.getDataPath())

def make_arena(arena_size=10, wall_height=1):
    wall_thickness = 0.5
    floor_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, arena_size/2, wall_thickness])
    floor_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, arena_size/2, wall_thickness], rgbaColor=[1, 1, 0, 1])
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=floor_collision_shape, baseVisualShapeIndex=floor_visual_shape, basePosition=[0, 0, -wall_thickness])
    
    wall_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, wall_thickness/2, wall_height/2])
    wall_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[arena_size/2, wall_thickness/2, wall_height/2], rgbaColor=[0.7, 0.7, 0.7, 1])

    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[0, arena_size/2, wall_height/2])
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[0, -arena_size/2, wall_height/2])

    wall_collision_shape = p.createCollisionShape(shapeType=p.GEOM_BOX, halfExtents=[wall_thickness/2, arena_size/2, wall_height/2])
    wall_visual_shape = p.createVisualShape(shapeType=p.GEOM_BOX, halfExtents=[wall_thickness/2, arena_size/2, wall_height/2], rgbaColor=[0.7, 0.7, 0.7, 1])

    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[arena_size/2, 0, wall_height/2])
    p.createMultiBody(baseMass=0, baseCollisionShapeIndex=wall_collision_shape, baseVisualShapeIndex=wall_visual_shape, basePosition=[-arena_size/2, 0, wall_height/2])

def fitness_function(creature_id):
    pos, _ = p.getBasePositionAndOrientation(creature_id)
    # Reward the creature for getting closer to the top of the mountain
    target_pos = (0, 0, 5)
    distance_to_target = np.linalg.norm(np.array(pos) - np.array(target_pos))
    return max(0, 10 - distance_to_target)

def run_simulation(creature, simulation_time=1000):
    p.resetSimulation()
    p.setGravity(0, 0, -10)
    arena_size = 20
    make_arena(arena_size=arena_size)
    
    # Load the mountain
    mountain_position = (0, 0, -1)
    mountain_orientation = p.getQuaternionFromEuler((0, 0, 0))
    p.setAdditionalSearchPath('shapes/')
    mountain_id = p.loadURDF("gaussian_pyramid.urdf", mountain_position, mountain_orientation, useFixedBase=1)

    # Load the creature from its URDF
    creature_xml = creature.to_xml()
    with open('test.urdf', 'w') as f:
        f.write(creature_xml)

    # Set initial position of the creature at the base of the mountain
    initial_position = (0, -arena_size/2 + 2, 0.5)
    creature_id = p.loadURDF('test.urdf', initial_position)

    # Get the number of joints in the creature
    num_joints = p.getNumJoints(creature_id)

    # Run the simulation
    for t in range(simulation_time):
        # Get the creature's action (joint torques)
        action = creature.get_action()

        # Ensure the action array has the same length as the number of joints
        if len(action) > num_joints:
            action = action[:num_joints]
        elif len(action) < num_joints:
            action.extend([0] * (num_joints - len(action)))

        # Apply the action to the creature's joints
        for i in range(num_joints):
            p.setJointMotorControl2(creature_id, i, p.TORQUE_CONTROL, force=action[i])

        p.stepSimulation()
        
        # Check if the creature has reached the top of the mountain
        pos, _ = p.getBasePositionAndOrientation(creature_id)
        if np.allclose(pos, [0, 0, 5], atol=0.1):
            print("Creature has reached the top of the mountain!")
            break
        
        # Check if the creature is out of bounds and reset it if necessary
        if abs(pos[0]) > arena_size/2 or abs(pos[1]) > arena_size/2:
            p.resetBasePositionAndOrientation(creature_id, initial_position, [0, 0, 0, 1])
        
        # Calculate fitness score and display
        fitness = fitness_function(creature_id)
        print(f"Time step {t}: Fitness = {fitness}")
        
        time.sleep(1/240)

    return fitness_function(creature_id)

def main():
    population_size = 20
    generations = 100
    gene_count = 10
    ga = GeneticAlgorithm(population_size=population_size, gene_count=gene_count)

    for generation in range(generations):
        fitness_scores = []
        for creature in ga.population:
            fitness = run_simulation(creature)
            fitness_scores.append(fitness)
            creature.fitness = fitness
        
        ga.evolve()
        
        best_fitness = max(fitness_scores)
        print(f"Generation {generation}: Best Fitness = {best_fitness}")

    p.disconnect()

if __name__ == "__main__":
    main()
