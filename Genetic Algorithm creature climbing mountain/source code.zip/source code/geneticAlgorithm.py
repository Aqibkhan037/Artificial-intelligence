
import random
import numpy as np
from creature import Creature

class GeneticAlgorithm:
    def __init__(self, population_size, gene_count, mutation_rate=0.01, crossover_rate=0.7):
        self.population_size = population_size
        self.gene_count = gene_count
        self.mutation_rate = mutation_rate
        self.crossover_rate = crossover_rate
        self.population = [Creature(gene_count=gene_count) for _ in range(population_size)]
    
    def evolve(self):
        new_population = []
        
        
        for _ in range(self.population_size // 2):
            parent1, parent2 = self.select_parents()
            offspring1, offspring2 = self.crossover(parent1, parent2)
            self.mutate(offspring1)
            self.mutate(offspring2)
            new_population.append(offspring1)
            new_population.append(offspring2)
        
        self.population = new_population
    
    def select_parents(self):
       
        max_fitness = sum(creature.fitness for creature in self.population)
        selection_probs = [creature.fitness / max_fitness for creature in self.population]
        parent1 = np.random.choice(self.population, p=selection_probs)
        parent2 = np.random.choice(self.population, p=selection_probs)
        return parent1, parent2
    
    def crossover(self, parent1, parent2):
        if random.random() < self.crossover_rate:
            crossover_point = random.randint(1, self.gene_count - 1)
            child1_genes = parent1.genes[:crossover_point] + parent2.genes[crossover_point:]
            child2_genes = parent2.genes[:crossover_point] + parent1.genes[crossover_point:]
        else:
            child1_genes = parent1.genes
            child2_genes = parent2.genes
        
        child1 = Creature(genes=child1_genes)
        child2 = Creature(genes=child2_genes)
        return child1, child2
    
    def mutate(self, creature):
        for i in range(self.gene_count):
            if random.random() < self.mutation_rate:
                creature.genes[i] = random.random() 
